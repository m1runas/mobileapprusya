package com.example.rusyaapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;

public class Phrase extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_phrase);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button saveButton10 = findViewById(R.id.gallery10);
        saveButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.f1);
                new SaveImageTask().execute(bitmap, "image10.jpg");
            }
        });

        Button saveButton11 = findViewById(R.id.gallery11);
        saveButton11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.f2);
                new SaveImageTask().execute(bitmap, "image11.jpg");
            }
        });

        Button saveButton12 = findViewById(R.id.gallery12);
        saveButton12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.f3);
                new SaveImageTask().execute(bitmap, "image12.jpg");
            }
        });
    }

    private class SaveImageTask extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... params) {
            Bitmap bitmap = (Bitmap) params[0];
            String filename = (String) params[1];
            saveImageToStorage(bitmap, filename);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(getApplicationContext(), "Загрузка завершена", Toast.LENGTH_SHORT).show();
        }
    }

    public void saveImageToStorage(Bitmap bitmap, String filename) {
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Фразы");
        directory.mkdirs(); // Создаем каталог, если его еще нет

        File file = new File(directory, filename);

        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            // Теперь ваше изображение сохранено по пути file.getAbsolutePath()
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}