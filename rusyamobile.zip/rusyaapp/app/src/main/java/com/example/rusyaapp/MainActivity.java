package com.example.rusyaapp;

import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
        import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tv_test1 = (TextView) findViewById(R.id.tv_link1);
        String textToFirstTv = "m1runas";
        SpannableString ss = new SpannableString(textToFirstTv);
        ss.setSpan(new URLSpan(String.valueOf(textToFirstTv)), 0, textToFirstTv.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv_test1.setText(ss);
        WebView webView;
        webView = findViewById(R.id.webvidew);

        // enable the javascript to load the url
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());

        // add the url of gif
        webView.loadUrl("https://steamuserimages-a.akamaihd.net/ugc/1830153364577064364/82648870FFD5B0A2A52AE560A816D32C27FE3955/?imw=396&imh=486&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true");
    }


    public void onClick(View view) {
        Intent intent = new Intent(this, Mood.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.tv_link1) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    public void blogView(View v) {
        Uri address = Uri.parse("https://vk.com/m1runas");
        Intent openlink = new Intent(Intent.ACTION_VIEW, address);
        startActivity(openlink);

    }
}