package com.example.rusyaapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;

public class Morning extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_morning2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button saveButton7 = findViewById(R.id.gallery7);
        saveButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.m1);
                new SaveImageTask().execute(bitmap, "image7.jpg");
            }
        });

        Button saveButton8 = findViewById(R.id.gallery8);
        saveButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.m2);
                new SaveImageTask().execute(bitmap, "image8.jpg");
            }
        });

        Button saveButton9 = findViewById(R.id.gallery9);
        saveButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.m3);
                new SaveImageTask().execute(bitmap, "image9.jpg");
            }
        });
    }

    private class SaveImageTask extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... params) {
            Bitmap bitmap = (Bitmap) params[0];
            String filename = (String) params[1];
            saveImageToStorage(bitmap, filename);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Toast.makeText(getApplicationContext(), "Загрузка завершена", Toast.LENGTH_SHORT).show();
        }
    }

    public void saveImageToStorage(Bitmap bitmap, String filename) {
        File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Утро");
        directory.mkdirs(); // Создаем каталог, если его еще нет

        File file = new File(directory, filename);

        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            // Теперь ваше изображение сохранено по пути file.getAbsolutePath()
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}